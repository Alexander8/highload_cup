﻿namespace Travels.Data.Dto
{
    public sealed class UserVisitToLocationDto
    {
        public long mark { get; set; }

        public long visited_at { get; set; }

        public string place { get; set; }
    }
}
