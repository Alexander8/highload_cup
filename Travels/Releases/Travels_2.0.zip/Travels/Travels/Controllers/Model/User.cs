﻿namespace Travels.Controllers.Model
{
    public sealed class User
    {
        public int? Id { get; set; }

        public string Email { get; set; }

        public string First_Name { get; set; }

        public string Last_Name { get; set; }

        public string Gender { get; set; }

        public long? Birth_Date { get; set; }
    }

    public sealed class UserToUpdate
    {
        public string Email { get; set; }

        public string First_Name { get; set; }

        public string Last_Name { get; set; }

        public string Gender { get; set; }

        public long? Birth_Date { get; set; }
    }
}
