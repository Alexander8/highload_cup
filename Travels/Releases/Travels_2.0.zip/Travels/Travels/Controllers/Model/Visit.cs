﻿namespace Travels.Controllers.Model
{
    public sealed class Visit
    {
        public int? Id { get; set; }

        public int? Location { get; set; }

        public int? User { get; set; }

        public long? Visited_At { get; set; }

        public int? Mark { get; set; }
    }

    public sealed class VisitToUpdate
    {
        public int? Location { get; set; }

        public int? User { get; set; }

        public long? Visited_At { get; set; }

        public int? Mark { get; set; }
    }
}
