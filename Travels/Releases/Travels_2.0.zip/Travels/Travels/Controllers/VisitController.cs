﻿using System.Collections.Generic;
using System.IO;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Travels.Controllers.Model;
using Travels.Data.Dal.Repository;
using Travels.Data.Dal.Service;
using Travels.Data.Dto;
using Travels.Data.Utils;

namespace Travels.Controllers
{
    [Route("visits")]
    public class VisitController : Controller
    {
        private static readonly object EmptyObject = new { };

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var visit = VisitRepository.GetVisit(id);
            if (visit == null)
                return NotFound();

            return Ok(visit);
        }

        [HttpPost("new")]
        public IActionResult Create([FromBody]Visit visit)
        {
            if (!IsVisitValid(visit))
                return BadRequest();

            // ReSharper disable PossibleInvalidOperationException
            UpdateStorageService.EnqueueCreateVisit(new CreateVisitParamsDto(visit.Id.Value, visit.Location.Value, visit.User.Value, visit.Visited_At.Value, visit.Mark.Value));
            // ReSharper restore PossibleInvalidOperationException

            return Ok(EmptyObject);
        }

        [HttpPost("{id}")]
        public IActionResult Update(int id, [FromBody]VisitToUpdate visitToUpdate)
        {
            var visitExists = VisitRepository.VisitExists(id);
            if (!visitExists)
                return NotFound();

            if (!IsVisitToUpdateValid(visitToUpdate))
                return BadRequest();

            UpdateStorageService.EnqueueCreateVisit(new UpdateVisitParamsDto(id, visitToUpdate.Location, visitToUpdate.User, visitToUpdate.Visited_At, visitToUpdate.Mark));

            return Ok(EmptyObject);
        }

        private bool IsVisitValid(Visit visit)
        {
            if (!ModelState.IsValid)
                return false;

            if (!visit.Id.HasValue)
                return false;

            if (!visit.Location.HasValue || !LocationRepository.LocationExists(visit.Location.Value))
                return false;

            if (!visit.User.HasValue || !UserRepository.UserExists(visit.User.Value))
                return false;

            if (!visit.Visited_At.HasValue || !ValidationUtil.IsVisitDateValid(visit.Visited_At.Value))
                return false;

            if (!visit.Mark.HasValue || !ValidationUtil.IsMarkValid(visit.Mark.Value))
                return false;

            return true;
        }

        private bool IsVisitToUpdateValid(VisitToUpdate visit)
        {
            if (!ModelState.IsValid)
                return false;

            if (!visit.Location.HasValue && !visit.User.HasValue && !visit.Visited_At.HasValue && !visit.Mark.HasValue)
                return false;

            if (visit.Location.HasValue && !LocationRepository.LocationExists(visit.Location.Value))
                return false;

            if (visit.User.HasValue && !UserRepository.UserExists(visit.User.Value))
                return false;

            if (visit.Visited_At.HasValue && !ValidationUtil.IsVisitDateValid(visit.Visited_At.Value))
                return false;

            if (visit.Mark.HasValue && !ValidationUtil.IsMarkValid(visit.Mark.Value))
                return false;

            if (!visit.Location.HasValue || !visit.Visited_At.HasValue || !visit.Mark.HasValue || !visit.User.HasValue)
            {
                Request.Body.Seek(0, SeekOrigin.Begin);
                using (var streamReader = new StreamReader(Request.Body))
                {
                    var rawRequest = streamReader.ReadToEnd();
                    var rawRequestObject = JsonConvert.DeserializeObject<Dictionary<string, object>>(rawRequest);

                    if (visit.Location == null && rawRequestObject.ContainsKey(nameof(visit.Location).ToLowerInvariant()))
                        return false;

                    if (visit.Visited_At == null && rawRequestObject.ContainsKey(nameof(visit.Visited_At).ToLowerInvariant()))
                        return false;

                    if (visit.Mark == null && rawRequestObject.ContainsKey(nameof(visit.Mark).ToLowerInvariant()))
                        return false;

                    if (visit.User == null && rawRequestObject.ContainsKey(nameof(visit.User).ToLowerInvariant()))
                        return false;
                }
            }

            return true;
        }
    }
}
