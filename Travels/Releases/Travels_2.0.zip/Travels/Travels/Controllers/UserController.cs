﻿using System.Collections.Generic;
using System.IO;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Travels.Controllers.Model;
using Travels.Data.Dal.Repository;
using Travels.Data.Dal.Service;
using Travels.Data.Dto;
using Travels.Data.Utils;

namespace Travels.Controllers
{
    [Route("users")]
    public class UserController : Controller
    {
        private static readonly object EmptyObject = new { };

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var user = UserRepository.GetFlatUser(id);
            if (user == null)
                return NotFound();

            return Ok(new
            {
                user.id,
                user.email,
                user.first_name,
                user.last_name,
                gender = ValidationUtil.GenderAsString(user.gender),
                user.birth_date
            });
        }

        [HttpGet("{id}/visits")]
        public IActionResult GetVisits(int id, long? fromDate, long? toDate, string country, int? toDistance)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var userExists = UserRepository.UserExists(id);
            if (!userExists)
                return NotFound();

            var userVisits = UserRepository.GetUserVisits(id, fromDate, toDate, country, toDistance);

            var result = new
            {
                visits = userVisits
            };

            return Ok(result);
        }

        [HttpPost("new")]
        public IActionResult Create([FromBody]User user)
        {
            if (!IsUserValid(user))
                return BadRequest();

            // ReSharper disable PossibleInvalidOperationException
            UpdateStorageService.EnqueueCreateUser(new CreateUserParamsDto(user.Id.Value, user.Email, user.First_Name, user.Last_Name, user.Gender, user.Birth_Date.Value));
            // ReSharper restore PossibleInvalidOperationException

            return Ok(EmptyObject);
        }

        [HttpPost("{id}")]
        public IActionResult Update(int id, [FromBody]UserToUpdate userToUpdate)
        {
            var userExists = UserRepository.UserExists(id);
            if (!userExists)
                return NotFound();

            if (!IsUserToUpdateValid(userToUpdate))
                return BadRequest();

            UpdateStorageService.EnqueueUpdateUser(new UpdateUserParamsDto(id, userToUpdate.Email, userToUpdate.First_Name, userToUpdate.Last_Name, userToUpdate.Gender, userToUpdate.Birth_Date));

            return Ok(EmptyObject);
        }

        private bool IsUserValid(User user)
        {
            if (!ModelState.IsValid)
                return false;

            if (!user.Id.HasValue)
                return false;

            if (!ValidationUtil.IsEmailValid(user.Email))
                return false;

            if (!ValidationUtil.IsFirstOrLastNameValid(user.First_Name))
                return false;

            if (!ValidationUtil.IsFirstOrLastNameValid(user.Last_Name))
                return false;

            if (!ValidationUtil.IsGenderValid(user.Gender))
                return false;

            if (!user.Birth_Date.HasValue || !ValidationUtil.IsBirthdayValid(user.Birth_Date.Value))
                return false;

            return true;
        }

        private bool IsUserToUpdateValid(UserToUpdate user)
        {
            if (!ModelState.IsValid)
                return false;

            if (user.Email != null && !ValidationUtil.IsEmailValid(user.Email))
                return false;

            if (user.First_Name != null && !ValidationUtil.IsFirstOrLastNameValid(user.First_Name))
                return false;

            if (user.Last_Name != null && !ValidationUtil.IsFirstOrLastNameValid(user.Last_Name))
                return false;

            if (user.Gender != null && !ValidationUtil.IsGenderValid(user.Gender))
                return false;

            if (user.Birth_Date.HasValue && !ValidationUtil.IsBirthdayValid(user.Birth_Date.Value))
                return false;

            if (user.Email == null || user.First_Name == null || user.Last_Name == null || user.Gender == null || !user.Birth_Date.HasValue)
            {
                Request.Body.Seek(0, SeekOrigin.Begin);
                using (var streamReader = new StreamReader(Request.Body))
                {
                    var rawRequest = streamReader.ReadToEnd();
                    var rawRequestObject = JsonConvert.DeserializeObject<Dictionary<string, object>>(rawRequest);

                    if (user.Email == null && rawRequestObject.ContainsKey(nameof(user.Email).ToLowerInvariant()))
                        return false;

                    if (user.First_Name == null && rawRequestObject.ContainsKey(nameof(user.First_Name).ToLowerInvariant()))
                        return false;

                    if (user.Last_Name == null && rawRequestObject.ContainsKey(nameof(user.Last_Name).ToLowerInvariant()))
                        return false;

                    if (user.Gender == null && rawRequestObject.ContainsKey(nameof(user.Gender).ToLowerInvariant()))
                        return false;

                    if (user.Birth_Date == null && rawRequestObject.ContainsKey(nameof(user.Birth_Date).ToLowerInvariant()))
                        return false;
                }
            }

            return true;
        }
    }
}
