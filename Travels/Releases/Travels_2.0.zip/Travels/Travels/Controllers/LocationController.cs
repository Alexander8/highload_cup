﻿using System.Collections.Generic;
using System.IO;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Travels.Controllers.Model;
using Travels.Data.Dal.Repository;
using Travels.Data.Dal.Service;
using Travels.Data.Dto;
using Travels.Data.Utils;

namespace Travels.Controllers
{
    [Route("locations")]
    public class LocationController : Controller
    {
        private static readonly object EmptyObject = new { };

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var location = LocationRepository.GetFlatLocation(id);
            if (location == null)
                return NotFound();

            return Ok(location);
        }

        [HttpGet("{id}/avg")]
        public IActionResult Avg(int id, long? fromDate, long? toDate, int? fromAge, int? toAge, string gender)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            if (gender != null && !ValidationUtil.IsGenderValid(gender))
                return BadRequest();

            var locationExists = LocationRepository.LocationExists(id);
            if (!locationExists)
                return NotFound();

            var averageMark = LocationRepository.GetAverageLocationMark(id, fromDate, toDate, fromAge, toAge, gender);

            return Ok(new
            {
                avg = averageMark
            });
        }

        [HttpPost("new")]
        public IActionResult Create([FromBody]Location location)
        {
            if (!IsLocationValid(location))
                return BadRequest();

            // ReSharper disable PossibleInvalidOperationException
            UpdateStorageService.EnqueueCreateLocation(new CreateLocationParamsDto(location.Id.Value, location.Place, location.Country, location.City, location.Distance.Value));
            // ReSharper restore PossibleInvalidOperationException

            return Ok(EmptyObject);
        }

        [HttpPost("{id}")]
        public IActionResult Update(int id, [FromBody]LocationToUpdate locationToUpdate)
        {
            var locationExists = LocationRepository.LocationExists(id);
            if (!locationExists)
                return NotFound();

            if (!IsLocationToUpdateValid(locationToUpdate))
                return BadRequest();

            UpdateStorageService.EnqueueUpdateLocation(new UpdateLocationParamsDto(id, locationToUpdate.Place, locationToUpdate.City, locationToUpdate.Country, locationToUpdate.Distance));

            return Ok(EmptyObject);
        }

        private bool IsLocationValid(Location location)
        {
            if (!ModelState.IsValid)
                return false;

            if (!location.Id.HasValue)
                return false;

            if (!ValidationUtil.IsPlaceValid(location.Place))
                return false;

            if (!ValidationUtil.IsCityValid(location.City))
                return false;

            if (!ValidationUtil.IsCountryValid(location.Country))
                return false;

            if (!location.Distance.HasValue)
                return false;

            return true;
        }

        private bool IsLocationToUpdateValid(LocationToUpdate location)
        {
            if (!ModelState.IsValid)
                return false;

            if (location.Place != null && !ValidationUtil.IsPlaceValid(location.Place))
                return false;

            if (location.City != null && !ValidationUtil.IsCityValid(location.City))
                return false;

            if (location.Country != null && !ValidationUtil.IsCountryValid(location.Country))
                return false;

            if (location.Place == null || location.City == null || location.Country == null || !location.Distance.HasValue)
            {
                Request.Body.Seek(0, SeekOrigin.Begin);
                using (var streamReader = new StreamReader(Request.Body))
                {
                    var rawRequest = streamReader.ReadToEnd();
                    var rawRequestObject = JsonConvert.DeserializeObject<Dictionary<string, object>>(rawRequest);

                    if (location.Place == null && rawRequestObject.ContainsKey(nameof(location.Place).ToLowerInvariant()))
                        return false;

                    if (location.City == null && rawRequestObject.ContainsKey(nameof(location.City).ToLowerInvariant()))
                        return false;

                    if (location.Country == null && rawRequestObject.ContainsKey(nameof(location.Country).ToLowerInvariant()))
                        return false;

                    if (location.Distance == null && rawRequestObject.ContainsKey(nameof(location.Distance).ToLowerInvariant()))
                        return false;
                }
            }

            return true;
        }
    }
}
