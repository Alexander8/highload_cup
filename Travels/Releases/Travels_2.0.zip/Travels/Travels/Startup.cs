﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Travels.Data.Dal;
using Travels.Data.Import;
using Travels.Data.Dal.Service;

namespace Travels
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseResponseBuffering();

            app.UseMvc();

            PopulateData();
        }

        private static void PopulateData()
        {
            var dataSource = new ArchiveDataSource();
            var data = dataSource.Read("/tmp/data/data.zip");

            Storage.LoadData(data);

            UpdateStorageService.Init();
        }
    }
}
