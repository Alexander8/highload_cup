﻿namespace Travels.Data
{
    internal static class DataConstants
    {
        public static readonly string Users = "users";
        public static readonly string Locations = "locations";
        public static readonly string Visits = "visits";
    }
}
