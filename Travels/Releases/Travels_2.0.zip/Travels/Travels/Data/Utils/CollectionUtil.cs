﻿using System;
using System.Collections.Generic;

namespace Travels.Data.Utils
{
    public static class CollectionUtil
    {
        public static IEnumerable<TValue> TakeWhileReverse<TKey, TValue>(this SortedList<TKey, TValue> collection, Func<TKey, bool> predicate)
        {
            for (var i = collection.Keys.Count - 1; i >= 0; --i)
            {
                if (predicate(collection.Keys[i]))
                    yield return collection.Values[i];
                else
                    yield break;
            }
        }
    }
}
