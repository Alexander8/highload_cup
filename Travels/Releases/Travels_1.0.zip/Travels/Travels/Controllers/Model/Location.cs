﻿namespace Travels.Controllers.Model
{
    public sealed class Location
    {
        public int? Id { get; set; }

        public string Place { get; set; }

        public string City { get; set; }

        public string Country { get; set; }

        public int? Distance { get; set; }
    }

    public sealed class LocationToUpdate
    {
        public string Place { get; set; }

        public string City { get; set; }

        public string Country { get; set; }

        public int? Distance { get; set; }
    }
}
