﻿using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Travels.Controllers.Model;
using Travels.Data.Storage.Repository;
using Travels.Data;
using Travels.Data.Storage.Service;

namespace Travels.Controllers
{
    [Route("locations")]
    public class LocationController : Controller
    {
        private static readonly object EmptyObject = new { };

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var location = await LocationRepository.GetFlatLocation(id);
            if (location == null)
                return NotFound();

            return Ok(new
            {
                location.id,
                location.place,
                location.country,
                location.city,
                location.distance
            });
        }

        [HttpGet("{id}/avg")]
        public async Task<IActionResult> Avg(int id, long? fromDate, long? toDate, int? fromAge, int? toAge, string gender)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            if (gender != null && !ValidationUtil.IsGenderValid(gender))
                return BadRequest();

            var averageMark = await LocationRepository.GetAverageLocationMark(id, fromDate, toDate, fromAge, toAge, gender);
            if (!averageMark.HasValue)
                return NotFound();

            return Ok(new
            {
                avg = averageMark
            });
        }

        [HttpPost("new")]
        public IActionResult Create([FromBody]Location location)
        {
            if (!IsLocationValid(location))
                return BadRequest();

            // ReSharper disable PossibleInvalidOperationException
            LocationRepository.CreateLocation(location.Id.Value, location.Place, location.Country, location.City, location.Distance.Value);
            // ReSharper restore PossibleInvalidOperationException

            return Ok(EmptyObject);
        }

        [HttpPost("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody]LocationToUpdate locationToUpdate)
        {
            var locationExists = await LocationRepository.LocationExists(id);
            if (!locationExists)
                return NotFound();

            if (!IsLocationToUpdateValid(locationToUpdate))
                return BadRequest();

            LocationService.UpdateLocation(id, locationToUpdate.Place, locationToUpdate.City, locationToUpdate.Country, locationToUpdate.Distance);

            return Ok(EmptyObject);
        }

        private bool IsLocationValid(Location location)
        {
            if (!ModelState.IsValid)
                return false;

            if (!location.Id.HasValue)
                return false;

            if (!ValidationUtil.IsPlaceValid(location.Place))
                return false;

            if (!ValidationUtil.IsCityValid(location.City))
                return false;

            if (!ValidationUtil.IsCountryValid(location.Country))
                return false;

            if (!location.Distance.HasValue)
                return false;

            return true;
        }

        private bool IsLocationToUpdateValid(LocationToUpdate location)
        {
            if (!ModelState.IsValid)
                return false;

            if (location.Place != null && !ValidationUtil.IsPlaceValid(location.Place))
                return false;

            if (location.City != null && !ValidationUtil.IsCityValid(location.City))
                return false;

            if (location.Country != null && !ValidationUtil.IsCountryValid(location.Country))
                return false;

            if (location.Place == null || location.City == null || location.Country == null || !location.Distance.HasValue)
            {
                Request.Body.Seek(0, SeekOrigin.Begin);
                using (var streamReader = new StreamReader(Request.Body))
                {
                    var rawRequest = streamReader.ReadToEnd();
                    var rawRequestObject = JsonConvert.DeserializeObject<Dictionary<string, object>>(rawRequest);

                    if (location.Place == null && rawRequestObject.ContainsKey(nameof(location.Place).ToLowerInvariant()))
                        return false;

                    if (location.City == null && rawRequestObject.ContainsKey(nameof(location.City).ToLowerInvariant()))
                        return false;

                    if (location.Country == null && rawRequestObject.ContainsKey(nameof(location.Country).ToLowerInvariant()))
                        return false;

                    if (location.Distance == null && rawRequestObject.ContainsKey(nameof(location.Distance).ToLowerInvariant()))
                        return false;
                }
            }

            return true;
        }
    }
}
