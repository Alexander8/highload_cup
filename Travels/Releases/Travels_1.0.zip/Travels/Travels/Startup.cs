﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Travels.Data.Import;
using Travels.Data.Storage;

namespace Travels
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseResponseBuffering();

            app.UseMvc();

            PopulateData();

            ThreadPool.QueueUserWorkItem(state => Warmup());
        }

        private static void PopulateData()
        {
            var dataSource = new ArchiveDataSource();
            var data = dataSource.Read("/tmp/data/data.zip");

            var storageManager = new StorageManager();
            storageManager.PopulateStorage(data);
        }

        private static void Warmup()
        {
            Console.WriteLine("Warmup started");

            var urls = new []
            {
                "http://localhost/users/1",
                "http://localhost/users/100",
                "http://localhost/users/1000",
                "http://localhost/users/2/visits",
                "http://localhost/users/200/visits?fromDate=946684800&toDate=1420070400",
                "http://localhost/users/2000/visits?toDistance=1000&country=Вьетнам",

                "http://localhost/locations/1",
                "http://localhost/locations/100",
                "http://localhost/locations/1000",
                "http://localhost/locations/200?fromDate=946684800&toDate=1420070400",
                "http://localhost/locations/2000?fromAge=10&toAge=100&gender=m",

                "http://localhost/users/1",
                "http://localhost/visits/100",
                "http://localhost/visits/1000"
            };

            var exeExists = File.Exists("/usr/bin/wget");
            Console.WriteLine("ExeExists: " + exeExists);

            var firstCall = true;

            foreach (var url in urls)
            {
                try
                {
                    using (var p = new Process())
                    {
                        p.StartInfo.FileName = "/usr/bin/wget";
                        p.StartInfo.Arguments = url;
                        p.StartInfo.CreateNoWindow = true;
                        //p.StartInfo.RedirectStandardOutput = true;
                        //p.StartInfo.RedirectStandardError = true;
                        p.StartInfo.UseShellExecute = false;
                        p.Start();

                        //p.OutputDataReceived += (sender, args) => Console.WriteLine(args.Data);
                        //p.ErrorDataReceived += (sender, args) => Console.WriteLine(args.Data);

                        //p.BeginOutputReadLine();
                        //p.BeginErrorReadLine();

                        if (!p.WaitForExit(firstCall ? 15000 : 1000))
                        {
                            Console.WriteLine("Killing process");
                            p.Kill();
                            Console.WriteLine("Process killed");
                        }

                        firstCall = false;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            Console.WriteLine("Warmup finished");
        }
    }
}
