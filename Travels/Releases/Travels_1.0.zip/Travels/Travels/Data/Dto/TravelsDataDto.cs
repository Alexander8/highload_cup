﻿using System.Collections.Generic;

namespace Travels.Data.Dto
{
    internal sealed class TravelsDataDto
    {
        public List<UserDto> Users { get; set; }

        public List<LocationDto> Locations { get; set; }

        public List<VisitDto> Visits { get; set; }
    }
}
