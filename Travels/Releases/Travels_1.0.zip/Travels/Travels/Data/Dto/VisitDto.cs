﻿namespace Travels.Data.Dto
{
    internal sealed class VisitDto
    {
        public int id { get; set; }

        public int location { get; set; }

        public int user { get; set; }

        public long visited_at { get; set; }

        public int mark { get; set; }
    }
}
