﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using Newtonsoft.Json;
using Travels.Data.Dto;

namespace Travels.Data.Import
{
    internal sealed class ArchiveDataSource
    {
        public TravelsDataDto Read(string path)
        {
            if (string.IsNullOrEmpty(path))
                throw new ArgumentNullException(nameof(path));

            if (!File.Exists(path))
                throw new FileNotFoundException(path);

            var data = new TravelsDataDto
            {
                Users = new List<UserDto>(),
                Locations = new List<LocationDto>(),
                Visits = new List<VisitDto>()
            };

            using (var fstream = new FileStream(path, FileMode.Open, FileAccess.Read))
            using (var archive = new ZipArchive(fstream, ZipArchiveMode.Read))
            {
                foreach (var entry in archive.Entries)
                {
                    if (entry.Name.StartsWith(DataConstants.Users))
                    {
                        data.Users.AddRange(Read<UserDto>(entry, DataConstants.Users));
                    }
                    else if (entry.Name.StartsWith(DataConstants.Locations))
                    {
                        data.Locations.AddRange(Read<LocationDto>(entry, DataConstants.Locations));
                    }
                    else if (entry.Name.StartsWith(DataConstants.Visits))
                    {
                        data.Visits.AddRange(Read<VisitDto>(entry, DataConstants.Visits));
                    }
                }
            }

            return data;
        }

        private static List<T> Read<T>(ZipArchiveEntry entry, string collectionName)
        {
            using (var stream = entry.Open())
            using (var reader = new StreamReader(stream, Encoding.UTF8))
            {
                var json = reader.ReadToEnd();
                var data = JsonConvert.DeserializeObject<Dictionary<string, List<T>>>(json);
                return data[collectionName];
            }
        }
    }
}
