﻿using Travels.Data.Storage.Repository;

namespace Travels.Data.Storage.Service
{
    public static class UserService
    {
        // ReSharper disable InconsistentNaming
        public static void UpdateUser(int id, string email, string first_name, string last_name, string gender, long? birth_date)
        // ReSharper restore InconsistentNaming
        {
            UserRepository.UpdateUser(id, email, first_name, last_name, gender, birth_date);

            if (gender != null || birth_date.HasValue)
            {
                LocationRepository.UpdateUser(id, gender, birth_date);
            }
        }
    }
}
