﻿using Travels.Data.Storage.Repository;

namespace Travels.Data.Storage.Service
{
    public static class LocationService
    {
        public static void UpdateLocation(int id, string place, string city, string country, int? distance)
        {
            LocationRepository.UpdateLocation(id, place, city, country, distance);

            if (place != null || country != null || distance.HasValue)
            {
                UserRepository.UpdateLocation(id, place, country, distance);
            }
        }
    }
}
