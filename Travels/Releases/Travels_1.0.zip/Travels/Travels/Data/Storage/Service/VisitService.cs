﻿using Travels.Data.Model;
using Travels.Data.Storage.Repository;

namespace Travels.Data.Storage.Service
{
    public static class VisitService
    {
        // ReSharper disable InconsistentNaming
        public static void CreateVisit(int id, int locationId, int userId, long visited_at, int mark)
        // ReSharper restore InconsistentNaming
        {
            VisitRepository.CreateVisit(new Visit
            {
                id = id,
                location = locationId,
                user = userId,
                visited_at = visited_at,
                mark = mark
            });

            LocationRepository.GetFlatLocation(locationId)
                .ContinueWith(getLocationTask =>
                {
                    var location = getLocationTask.Result;
                    return UserRepository.CreateUserVisit(
                        userId,
                        id,
                        visited_at,
                        mark,
                        locationId,
                        location.country,
                        location.place,
                        location.distance
                    );
                });

            UserRepository.GetFlatUser(userId)
                .ContinueWith(getUserTask =>
                {
                    var user = getUserTask.Result;
                    return LocationRepository.CreateLocationVisit(
                        locationId,
                        id,
                        visited_at,
                        mark,
                        userId,
                        user.birth_date,
                        user.gender);
                });
        }

        // ReSharper disable InconsistentNaming
        public static void UpdateVisit(int id, int? locationId, int? userId, long? visited_at, int? mark)
        // ReSharper restore InconsistentNaming
        {
            VisitRepository.GetVisit(id)
                .ContinueWith(getVisitTask => UpdateVisit(id, locationId, userId, visited_at, mark, getVisitTask.Result));
        }

        // ReSharper disable InconsistentNaming
        private static void UpdateVisit(int id, int? locationId, int? userId, long? visited_at, int? mark, Visit oldVisit)
        // ReSharper restore InconsistentNaming
        {
            VisitRepository.UpdateVisit(id, locationId, userId, visited_at, mark);

            if (locationId.HasValue)
            {
                LocationRepository.GetFlatLocation(locationId.Value).ContinueWith(getLocationTask =>
                {
                    var location = getLocationTask.Result;
                    return UserRepository.UpdateUserVisit(
                        userId,
                        location.id,
                        location.country,
                        location.place,
                        location.distance,
                        id,
                        visited_at,
                        mark,
                        oldVisit
                    );
                });
            }
            else
            {
                LocationRepository.GetFlatLocation(oldVisit.location).ContinueWith(getLocationTask =>
                {
                    var oldLocation = getLocationTask.Result;
                    return UserRepository.UpdateUserVisit(
                        userId,
                        id,
                        visited_at,
                        mark,
                        oldVisit,
                        oldLocation);
                });
            }

            if (userId.HasValue)
            {
                UserRepository.GetFlatUser(userId.Value).ContinueWith(getUserTask =>
                {
                    var user = getUserTask.Result;
                    return LocationRepository.UpdateLocationVisit(
                        locationId,
                        user.id,
                        user.birth_date,
                        user.gender,
                        id,
                        visited_at,
                        mark,
                        oldVisit
                    );
                });
            }
            else
            {
                UserRepository.GetFlatUser(oldVisit.user).ContinueWith(getUserTask =>
                {
                    var oldUser = getUserTask.Result;
                    return LocationRepository.UpdateLocationVisit(
                        locationId,
                        id,
                        visited_at,
                        mark,
                        oldVisit,
                        oldUser);
                });
            }
        }
    }
}
