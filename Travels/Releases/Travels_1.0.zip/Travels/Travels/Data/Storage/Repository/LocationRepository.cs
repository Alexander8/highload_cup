﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using Travels.Data.Model;

namespace Travels.Data.Storage.Repository
{
    internal static class LocationRepository
    {
        public static Task<Location> GetFlatLocation(int id)
        {
            var locations = StorageClient.Locations;
            return locations
                .Find(u => u.id == id)
                .Project(u => new Location
                {
                    id = u.id,
                    place = u.place,
                    country = u.country,
                    city = u.city,
                    distance = u.distance
                })
                .FirstOrDefaultAsync();
        }

        public static Task<bool> LocationExists(int id)
        {
            var locations = StorageClient.Locations;
            return locations
                .Find(l => l.id == id)
                .Project(l => l.id)
                .AnyAsync();
        }

        public static async Task<double?> GetAverageLocationMark(int id, long? fromDate, long? toDate, int? fromAge, int? toAge, string gender)
        {
            var locations = StorageClient.Locations;

            var query = locations.Aggregate()
                .Match(Builders<Location>.Filter.Eq(l => l.id, id))
                .Unwind(u => u.users)
                .Unwind(new StringFieldDefinition<BsonDocument>(nameof(Location.users) + "." + nameof(LocationUser.visits)));

            if (fromDate.HasValue)
            {
                query = query.Match(new BsonDocument
                {
                    {
                        nameof(Location.users) + "." + nameof(LocationUser.visits) + "." + nameof(LocationVisit.visited_at), new BsonDocument("$gt", fromDate.Value)
                    }
                });
            }

            if (toDate.HasValue)
            {
                query = query.Match(new BsonDocument
                {
                    {
                        nameof(Location.users) + "." + nameof(LocationUser.visits) + "." + nameof(LocationVisit.visited_at), new BsonDocument("$lt", toDate.Value)
                    }
                });
            }

            if (fromAge.HasValue)
            {
                query = query.Match(new BsonDocument
                {
                    {
                        nameof(Location.users) + "." + nameof(LocationUser.user_birth_date), new BsonDocument("$lt", ValidationUtil.AgeToTimestamp(fromAge.Value))
                    }
                });
            }

            if (toAge.HasValue)
            {
                query = query.Match(new BsonDocument
                {
                    {
                        nameof(Location.users) + "." + nameof(LocationUser.user_birth_date), new BsonDocument("$gt", ValidationUtil.AgeToTimestamp(toAge.Value))
                    }
                });
            }

            if (!string.IsNullOrEmpty(gender))
            {
                query = query.Match(new BsonDocument
                {
                    {
                        nameof(Location.users) + "." + nameof(LocationUser.user_gender), new BsonDocument("$eq", gender)
                    }
                });
            }

            query = query.Group(new BsonDocument
            {
                {
                    "_id", string.Empty
                },
                {
                   "avg", new BsonDocument("$avg", "$" + nameof(Location.users) + "." + nameof(LocationUser.visits) + "." + nameof(LocationVisit.mark))
                }
            });

            var result = await query.FirstOrDefaultAsync();
            if (result == null)
            {
                var locationExists = await LocationExists(id);
                if (locationExists)
                {
                    return 0.0d;
                }

                return null;
            }

            var avg = result["avg"].AsDouble;
            return Math.Round(avg, 5);
        }

        public static Task CreateLocation(int id, string place, string country, string city, int distance)
        {
            var locations = StorageClient.Locations;
            return locations.InsertOneAsync(new Location
            {
                id = id,
                place = place,
                country = country,
                city = city,
                distance = distance,
                users = new List<LocationUser>()
            });
        }

        public static Task CreateLocationVisit(int location_id, int visit_id, long visited_at, int mark, int user_id, long user_birth_date, string user_gender)
        {
            var locations = StorageClient.Locations;

            return locations
                .Find(Builders<Location>.Filter.Eq(l => l.id, location_id) & Builders<Location>.Filter.ElemMatch(l => l.users, u => u.user_id == user_id))
                .AnyAsync()
                .ContinueWith(checkTask =>
                {
                    if (checkTask.Result)
                    {
                        return locations.UpdateOneAsync(
                            Builders<Location>.Filter.Eq(l => l.id, location_id) & Builders<Location>.Filter.ElemMatch(l => l.users, u => u.user_id == user_id),
                            Builders<Location>.Update.Push(l => l.users[-1].visits, new LocationVisit
                            {
                                visit_id = visit_id,
                                visited_at = visited_at,
                                mark = mark
                            })
                        );
                    }
                    else
                    {
                        return locations.UpdateOneAsync(
                            l => l.id == location_id,
                            Builders<Location>.Update.Push(l => l.users, new LocationUser
                            {
                                user_id = user_id,
                                user_birth_date = user_birth_date,
                                user_gender = user_gender,
                                visits = new List<LocationVisit>
                                {
                                    new LocationVisit
                                    {
                                        visit_id = visit_id,
                                        visited_at = visited_at,
                                        mark = mark
                                    }
                                }
                            }));
                    } 
                });
        }

        public static Task UpdateUser(int userId, string gender, long? birth_date)
        {
            var locations = StorageClient.Locations;

            UpdateDefinition<Location> setOperation = null;
            if (gender != null)
                setOperation = Builders<Location>.Update.Set(l => l.users[-1].user_gender, gender);

            if (birth_date.HasValue)
            {
                setOperation = setOperation != null
                    ? setOperation.Set(l => l.users[-1].user_birth_date, birth_date.Value)
                    : Builders<Location>.Update.Set(l => l.users[-1].user_birth_date, birth_date.Value);
            }

            if (setOperation == null)
                return Task.CompletedTask;

            return locations.UpdateManyAsync(
                Builders<Location>.Filter.ElemMatch(l => l.users, v => v.user_id == userId),
                setOperation);
        }

        public static Task UpdateLocation(int id, string place, string city, string country, int? distance)
        {
            var locations = StorageClient.Locations;

            UpdateDefinition<Location> setOperation = null;
            if (place != null)
                setOperation = Builders<Location>.Update.Set(l => l.place, place);

            if (city != null)
            {
                setOperation = setOperation == null
                    ? Builders<Location>.Update.Set(l => l.city, city)
                    : setOperation.Set(l => l.city, city);
            }

            if (country != null)
            {
                setOperation = setOperation == null
                    ? Builders<Location>.Update.Set(l => l.country, country)
                    : setOperation.Set(l => l.country, country);
            }

            if (distance.HasValue)
            {
                setOperation = setOperation == null
                    ? Builders<Location>.Update.Set(l => l.distance, distance.Value)
                    : setOperation.Set(l => l.distance, distance.Value);
            }

            if (setOperation == null)
                return Task.CompletedTask;

            return locations.UpdateOneAsync(l => l.id == id, setOperation);
        }

        public static Task UpdateLocationVisit(int? locationId, int userId, long birth_date, string gender, int visit_id, long? visited_at, int? mark, Visit oldVisit)
        {
            var removeOldVisitTask = RemoveVisitFromLocation(oldVisit.location, oldVisit.user, visit_id);

            var addNewVisitTask = CreateLocationVisit(
                locationId ?? oldVisit.location,
                visit_id,
                visited_at ?? oldVisit.visited_at,
                mark ?? oldVisit.mark,
                userId,
                birth_date,
                gender);

            return Task.WhenAll(removeOldVisitTask, addNewVisitTask);
        }

        public static Task UpdateLocationVisit(int? locationId, int visit_id, long? visited_at, int? mark, Visit oldVisit, User oldUser)
        {
            var removeOldVisitTask = RemoveVisitFromLocation(oldVisit.location, oldVisit.user, visit_id);

            var addNewVisitTask = CreateLocationVisit(
                locationId ?? oldVisit.location,
                visit_id,
                visited_at ?? oldVisit.visited_at,
                mark ?? oldVisit.mark,
                oldUser.id,
                oldUser.birth_date,
                oldUser.gender);

            return Task.WhenAll(removeOldVisitTask, addNewVisitTask);
        }

        private static Task RemoveVisitFromLocation(int locationId, int userId, int visitId)
        {
            var locations = StorageClient.Locations;

            return locations.UpdateOneAsync(
                Builders<Location>.Filter.Eq(l => l.id, locationId) & Builders<Location>.Filter.ElemMatch(l => l.users, l => l.user_id == userId),
                Builders<Location>.Update.PullFilter(
                    nameof(Location.users) + ".$." + nameof(LocationUser.visits),
                    Builders<LocationVisit>.Filter.Eq(lv => lv.visit_id, visitId))
                );
        }
    }
}
