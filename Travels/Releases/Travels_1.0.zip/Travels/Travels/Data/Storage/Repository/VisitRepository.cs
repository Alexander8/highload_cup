﻿using System.Threading.Tasks;
using MongoDB.Driver;
using Travels.Data.Model;

namespace Travels.Data.Storage.Repository
{
    internal static class VisitRepository
    {
        public static Task<Visit> GetVisit(int id)
        {
            var visits = StorageClient.Visits;
            return visits.Find(u => u.id == id).FirstOrDefaultAsync();
        }

        public static Task CreateVisit(Visit visit)
        {
            var visits = StorageClient.Visits;
            return visits.InsertOneAsync(visit);
        }

        public static Task UpdateVisit(int id, int? location, int? user, long? visited_at, int? mark)
        {
            var visits = StorageClient.Visits;

            UpdateDefinition<Visit> setOperation = null;
            if (location.HasValue)
                setOperation = Builders<Visit>.Update.Set(v => v.location, location.Value);

            if (user.HasValue)
            {
                setOperation = setOperation == null
                    ? Builders<Visit>.Update.Set(v => v.user, user.Value)
                    : setOperation.Set(v => v.user, user.Value);
            }

            if (visited_at.HasValue)
            {
                setOperation = setOperation == null
                    ? Builders<Visit>.Update.Set(v => v.visited_at, visited_at.Value)
                    : setOperation.Set(v => v.visited_at, visited_at.Value);
            }

            if (mark.HasValue)
            {
                setOperation = setOperation == null
                    ? Builders<Visit>.Update.Set(v => v.mark, mark.Value)
                    : setOperation.Set(v => v.mark, mark.Value);
            }

            if (setOperation == null)
                return Task.CompletedTask;

            return visits.UpdateOneAsync(v => v.id == id, setOperation);
        }

        public static Task<bool> VisitExists(int id)
        {
            var visits = StorageClient.Visits;
            return visits
                .Find(v => v.id == id)
                .Project(v => v.id)
                .AnyAsync();
        }
    }
}
