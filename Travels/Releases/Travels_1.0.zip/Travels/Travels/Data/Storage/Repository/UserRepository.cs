﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using MongoDB.Bson;
using MongoDB.Driver;
using Travels.Data.Model;
using Travels.Data.Dto;

namespace Travels.Data.Storage.Repository
{
    internal static class UserRepository
    {
        public static Task<User> GetFlatUser(int id)
        {
            var users = StorageClient.Users;
            return users
                .Find(u => u.id == id)
                .Project(u => new User
                {
                    id = u.id,
                    email = u.email,
                    first_name = u.first_name,
                    last_name = u.last_name,
                    gender = u.gender,
                    birth_date = u.birth_date
                })
                .FirstOrDefaultAsync();
        }

        public static Task<bool> UserExists(int id)
        {
            var users = StorageClient.Users;
            return users
                .Find(u => u.id == id)
                .Project(u => u.id)
                .AnyAsync();
        }

        public static Task<List<UserVisitToLocationDto>> GetUserVisits(int id, long? fromDate, long? toDate, string country, int? toDistance)
        {
            var users = StorageClient.Users;

            var query = users.Aggregate()
                .Match(Builders<User>.Filter.Eq(u => u.id, id))
                .Unwind(u => u.locations)
                .Unwind(new StringFieldDefinition<BsonDocument>(nameof(User.locations) + "." + nameof(UserLocation.visits))); ;

            if (fromDate.HasValue)
            {
                query = query.Match(new BsonDocument
                {
                    {
                        nameof(User.locations) + "." + nameof(UserLocation.visits) + "." + nameof(UserVisit.visited_at), new BsonDocument("$gt", fromDate.Value)
                    }
                });
            }

            if (toDate.HasValue)
            {
                query = query.Match(new BsonDocument
                {
                    {
                        nameof(User.locations) + "." + nameof(UserLocation.visits) + "." + nameof(UserVisit.visited_at), new BsonDocument("$lt", toDate.Value)
                    }
                });
            }

            if (!string.IsNullOrEmpty(country))
            {
                query = query.Match(new BsonDocument
                {
                    {
                        nameof(User.locations) + "." + nameof(UserLocation.location_country), new BsonDocument("$eq", country)
                    }
                });
            }

            if (toDistance.HasValue)
            {
                query = query.Match(new BsonDocument
                {
                    {
                        nameof(User.locations) + "." + nameof(UserLocation.location_distance), new BsonDocument("$lt", toDistance.Value)
                    }
                });
            }

            query = query.Sort(new BsonDocument
            {
                { nameof(User.locations) + "." + nameof(UserLocation.visits) + "." + nameof(UserVisit.visited_at), 1 }
            });

            var projection = Builders<BsonDocument>.Projection
                .Include(nameof(User.locations) + "." + nameof(UserLocation.location_place))
                .Include(nameof(User.locations) + "." + nameof(UserLocation.visits) + "." + nameof(UserVisit.visited_at))
                .Include(nameof(User.locations) + "." + nameof(UserLocation.visits) + "." + nameof(UserVisit.mark));

            var projectionQuery = query.Project(projection);

            return projectionQuery.ToListAsync()
                .ContinueWith(getUserVisitsTask =>
                {
                    var userVisits = getUserVisitsTask.Result;

                    return userVisits
                        .Select(uv =>
                        {
                            var location = uv[nameof(User.locations)].AsBsonDocument;
                            var visit = location[nameof(UserLocation.visits)].AsBsonDocument;

                            return new UserVisitToLocationDto
                            {
                                place = location[nameof(UserLocation.location_place)].AsString,
                                visited_at = visit[nameof(UserVisit.visited_at)].AsInt64,
                                mark = visit[nameof(UserVisit.mark)].AsInt32,
                            };
                        })
                        .ToList();
                });
        }

        public static Task CreateUser(int id, string email, string first_name, string last_name, string gender, long birth_date)
        {
            var users = StorageClient.Users;
            return users.InsertOneAsync(new User
            {
                id = id,
                email = email,
                first_name = first_name,
                last_name = last_name,
                gender = gender,
                birth_date = birth_date,
                locations = new List<UserLocation>()
            });
        }

        public static Task CreateUserVisit(int user_id, int visit_id, long visited_at, int mark, int location_id, string country, string place, int distance)
        {
            var users = StorageClient.Users;

            return users
                .Find(Builders<User>.Filter.Eq(u => u.id, user_id) & Builders<User>.Filter.ElemMatch(l => l.locations, l => l.location_id == location_id))
                .AnyAsync()
                .ContinueWith(checkTask =>
                {
                    if (checkTask.Result)
                    {
                        return users.UpdateOneAsync(
                            Builders<User>.Filter.Eq(u => u.id, user_id) & Builders<User>.Filter.ElemMatch(l => l.locations, l => l.location_id == location_id),
                            Builders<User>.Update.Push(u => u.locations[-1].visits, new UserVisit
                            {
                                visit_id = visit_id,
                                visited_at = visited_at,
                                mark = mark
                            })
                        );
                    }
                    else
                    {
                        return users.UpdateOneAsync(
                            u => u.id == user_id,
                            Builders<User>.Update.Push(u => u.locations, new UserLocation
                            {
                                location_id = location_id,
                                location_country = country,
                                location_place = place,
                                location_distance = distance,
                                visits = new List<UserVisit>
                                {
                                    new UserVisit
                                    {
                                        visit_id = visit_id,
                                        visited_at = visited_at,
                                        mark = mark
                                    }
                                }
                            }));
                    }
                });
        }

        public static Task UpdateUser(int id, string email, string first_name, string last_name, string gender, long? birth_date)
        {
            var users = StorageClient.Users;

            UpdateDefinition<User> setOperation = null;
            if (email != null)
                setOperation = Builders<User>.Update.Set(u => u.email, email);

            if (first_name != null)
            {
                setOperation = setOperation == null
                    ? Builders<User>.Update.Set(u => u.first_name, first_name)
                    : setOperation.Set(u => u.first_name, first_name);
            }

            if (last_name != null)
            {
                setOperation = setOperation == null
                    ? Builders<User>.Update.Set(u => u.last_name, last_name)
                    : setOperation.Set(u => u.last_name, last_name);
            }

            if (gender != null)
            {
                setOperation = setOperation == null
                    ? Builders<User>.Update.Set(u => u.gender, gender)
                    : setOperation.Set(u => u.gender, gender);
            }

            if (birth_date.HasValue)
            {
                setOperation = setOperation == null
                    ? Builders<User>.Update.Set(u => u.birth_date, birth_date)
                    : setOperation.Set(u => u.birth_date, birth_date);
            }

            if (setOperation == null)
                return Task.CompletedTask;

            return users.UpdateOneAsync(u => u.id == id, setOperation);
        }

        public static Task UpdateLocation(int locationId, string place, string country, int? distance)
        {
            var users = StorageClient.Users;

            UpdateDefinition<User> setOperation = null;
            if (place != null)
                setOperation = Builders<User>.Update.Set(u => u.locations[-1].location_place, place);

            if (country != null)
            {
                setOperation = setOperation != null
                    ? setOperation.Set(u => u.locations[-1].location_country, country)
                    : Builders<User>.Update.Set(u => u.locations[-1].location_country, country);
            }

            if (distance.HasValue)
            {
                setOperation = setOperation != null
                    ? setOperation.Set(u => u.locations[-1].location_distance, distance)
                    : Builders<User>.Update.Set(u => u.locations[-1].location_distance, distance);
            }

            if (setOperation == null)
                return Task.CompletedTask;

            return users.UpdateManyAsync(
                Builders<User>.Filter.ElemMatch(u => u.locations, u => u.location_id == locationId),
                setOperation);
        }

        public static Task UpdateUserVisit(int? userId, int location_id, string country, string place, int distance, int visit_id, long? visited_at, int? mark, Visit oldVisit)
        {
            var removeOldVisitTask = RemoveVisitFromUser(oldVisit.user, oldVisit.location, visit_id);

            var addNewVisitTask = CreateUserVisit(
                userId ?? oldVisit.user, 
                visit_id, 
                visited_at ?? oldVisit.visited_at, 
                mark ?? oldVisit.mark, 
                location_id, 
                country, 
                place, 
                distance);

            return Task.WhenAll(removeOldVisitTask, addNewVisitTask);
        }

        public static Task UpdateUserVisit(int? userId, int visit_id, long? visited_at, int? mark, Visit oldVisit, Location oldLocation)
        {
            var removeOldVisitTask = RemoveVisitFromUser(oldVisit.user, oldVisit.location, visit_id);

            var addNewVisitTask = CreateUserVisit(
                userId ?? oldVisit.user, 
                visit_id, 
                visited_at ?? oldVisit.visited_at, 
                mark ?? oldVisit.mark, 
                oldLocation.id, 
                oldLocation.country, 
                oldLocation.place,
                oldLocation.distance);

            return Task.WhenAll(removeOldVisitTask, addNewVisitTask);
        }

        private static Task RemoveVisitFromUser(int userId, int locationId, int visitId)
        {
            var users = StorageClient.Users;

            return users.UpdateOneAsync(
                Builders<User>.Filter.Eq(u => u.id, userId) & Builders<User>.Filter.ElemMatch(l => l.locations, l => l.location_id == locationId),
                Builders<User>.Update.PullFilter(
                    nameof(User.locations) + ".$." + nameof(UserLocation.visits),
                    Builders<UserVisit>.Filter.Eq(uv => uv.visit_id, visitId)
                )
            );
        }
    }
}
