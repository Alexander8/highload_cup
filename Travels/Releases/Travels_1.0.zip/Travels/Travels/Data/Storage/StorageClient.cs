﻿using MongoDB.Driver;
using Travels.Data.Model;

namespace Travels.Data.Storage
{
    internal static class StorageClient
    {
        internal static readonly IMongoDatabase Database;
        internal static readonly IMongoCollection<User> Users;
        internal static readonly IMongoCollection<Location> Locations;
        internal static readonly IMongoCollection<Visit> Visits;

        static StorageClient()
        {
            var urlBuilder = new MongoUrlBuilder
            {
                DatabaseName = "travels",
                Server = new MongoServerAddress("127.0.0.1", 27017),
                MinConnectionPoolSize = 100,
                MaxConnectionPoolSize = 250,
                WaitQueueMultiple = 10
            };

            var client = new MongoClient(urlBuilder.ToMongoUrl());

            Database = client.GetDatabase(urlBuilder.DatabaseName);

            Users = Database.GetCollection<User>(DataConstants.Users);
            Locations = Database.GetCollection<Location>(DataConstants.Locations);
            Visits = Database.GetCollection<Visit>(DataConstants.Visits);
        }
    }
}
