﻿using System;
using System.Collections.Generic;
using System.Linq;
using MongoDB.Bson;
using MongoDB.Driver;
using Travels.Data.Dto;
using Travels.Data.Model;

namespace Travels.Data.Storage
{
    internal sealed class StorageManager
    {
        public void PopulateStorage(TravelsDataDto data)
        {
            Validate(data);

            CreateCollections();
            UploadData(data);
            CreateIndexes();
        }

        private static void Validate(TravelsDataDto data)
        {
            if (data == null)
                throw new ArgumentNullException(nameof(data));

            if (data.Users == null)
                throw new ArgumentException(nameof(data.Users));

            if (data.Locations == null)
                throw new ArgumentException(nameof(data.Locations));

            if (data.Visits == null)
                throw new ArgumentException(nameof(data.Visits));
        }

        private static void CreateCollections()
        {
            var db = StorageClient.Database;

            db.DropCollection(DataConstants.Users);
            db.DropCollection(DataConstants.Locations);
            db.DropCollection(DataConstants.Visits);

            db.CreateCollection(DataConstants.Users);
            db.CreateCollection(DataConstants.Locations);
            db.CreateCollection(DataConstants.Visits);
        }

        private static void UploadData(TravelsDataDto data)
        {
            var users = GetUsers(data);
            StorageClient.Users.InsertMany(users);

            var locations = GetLocations(data);
            StorageClient.Locations.InsertMany(locations);

            var visits = GetVisits(data);
            StorageClient.Visits.InsertMany(visits);
        }

        private static IEnumerable<User> GetUsers(TravelsDataDto data)
        {
            var users = data.Users.Select(u => new User
            {
                id = u.id,
                email = u.email,
                first_name = u.first_name,
                last_name = u.last_name,
                gender = u.gender,
                birth_date = u.birth_date,
                locations = new List<UserLocation>()
            })
            .ToDictionary(u => u.id);

            var locations = data.Locations.ToDictionary(l => l.id);
            var usersWithLocations = new Dictionary<int, Dictionary<int, UserLocation>>();

            foreach (var visit in data.Visits)
            {
                if (!usersWithLocations.TryGetValue(visit.user, out Dictionary<int, UserLocation> userLocations))
                {
                    userLocations = new Dictionary<int, UserLocation>();
                    usersWithLocations.Add(visit.user, userLocations);
                }

                if (!userLocations.TryGetValue(visit.location, out UserLocation userLocation))
                {
                    if (!locations.TryGetValue(visit.location, out LocationDto l))
                        continue;

                    userLocation = new UserLocation
                    {
                        location_id = l.id,
                        location_place = l.place,
                        location_country = l.country,
                        location_distance = l.distance,
                        visits = new List<UserVisit>()
                    };

                    userLocations.Add(visit.location, userLocation);
                }

                userLocation.visits.Add(new UserVisit
                {
                    visit_id = visit.id,
                    visited_at = visit.visited_at,
                    mark = visit.mark
                });
            }

            foreach (var userLocations in usersWithLocations)
            {
                if (!users.TryGetValue(userLocations.Key, out User u))
                    continue;

                u.locations.AddRange(userLocations.Value.Values);
            }

            return users.Values;
        }

        private static IEnumerable<Location> GetLocations(TravelsDataDto data)
        {
            var locations = data.Locations.Select(l => new Location
            {
                id = l.id,
                place = l.place,
                country = l.country,
                city = l.city,
                distance = l.distance,
                users = new List<LocationUser>()
            })
            .ToDictionary(l => l.id);

            var users = data.Users.ToDictionary(u => u.id);
            var locationsWithUsers = new Dictionary<int, Dictionary<int, LocationUser>>();

            foreach (var visit in data.Visits)
            {
                if (!locationsWithUsers.TryGetValue(visit.location, out Dictionary<int, LocationUser> locationUsers))
                {
                    locationUsers = new Dictionary<int, LocationUser>();
                    locationsWithUsers.Add(visit.location, locationUsers);
                }

                if (!locationUsers.TryGetValue(visit.user, out LocationUser locationUser))
                {
                    if (!users.TryGetValue(visit.user, out UserDto u))
                        continue;

                    locationUser = new LocationUser
                    {
                        user_id = u.id,
                        user_birth_date = u.birth_date,
                        user_gender = u.gender,
                        visits = new List<LocationVisit>()
                    };

                    locationUsers.Add(u.id, locationUser);
                }

                locationUser.visits.Add(new LocationVisit
                {
                    visit_id = visit.id,
                    visited_at = visit.visited_at,
                    mark = visit.mark
                });
            }

            foreach (var locationUsers in locationsWithUsers)
            {
                if (!locations.TryGetValue(locationUsers.Key, out Location l))
                    continue;

                l.users.AddRange(locationUsers.Value.Values);
            }

            return locations.Values;
        }

        private static IEnumerable<Visit> GetVisits(TravelsDataDto data)
        {
            return data.Visits.Select(v => new Visit
            {
                id = v.id,
                location = v.location,
                user = v.user,
                visited_at = v.visited_at,
                mark = v.mark
            });
        }

        private static void CreateIndexes()
        {
            StorageClient.Users.Indexes.CreateMany(new[]
            {
                new CreateIndexModel<User>(Builders<User>.IndexKeys.Ascending(_ => _.id)),

                new CreateIndexModel<User>(new BsonDocumentIndexKeysDefinition<User>(new BsonDocument
                {
                    { nameof(User.locations) + "." + nameof(UserLocation.location_id), 1 }
                })),

                new CreateIndexModel<User>(new BsonDocumentIndexKeysDefinition<User>(new BsonDocument
                {
                    { nameof(User.locations) + "." + nameof(UserLocation.location_country), 1 }
                })),

                new CreateIndexModel<User>(new BsonDocumentIndexKeysDefinition<User>(new BsonDocument
                {
                    { nameof(User.locations) + "." + nameof(UserLocation.location_distance), 1 }
                })),

                new CreateIndexModel<User>(new BsonDocumentIndexKeysDefinition<User>(new BsonDocument
                {
                    { nameof(User.locations) + "." + nameof(UserLocation.visits) + "." + nameof(UserVisit.visit_id), 1 }
                })),

                new CreateIndexModel<User>(new BsonDocumentIndexKeysDefinition<User>(new BsonDocument
                {
                    { nameof(User.locations) + "." + nameof(UserLocation.visits) + "." + nameof(UserVisit.visited_at), 1 }
                })),
            });

            StorageClient.Locations.Indexes.CreateMany(new[]
            {
                new CreateIndexModel<Location>(Builders<Location>.IndexKeys.Ascending(_ => _.id)),

                new CreateIndexModel<Location>(new BsonDocumentIndexKeysDefinition<Location>(new BsonDocument
                {
                    { nameof(Location.users) + "." + nameof(LocationUser.user_id), 1 }
                })),

                new CreateIndexModel<Location>(new BsonDocumentIndexKeysDefinition<Location>(new BsonDocument
                {
                    { nameof(Location.users) + "." + nameof(LocationUser.user_birth_date), 1 }
                })),

                new CreateIndexModel<Location>(new BsonDocumentIndexKeysDefinition<Location>(new BsonDocument
                {
                    { nameof(Location.users) + "." + nameof(LocationUser.visits) + "." + nameof(LocationVisit.visit_id), 1 }
                })),

                new CreateIndexModel<Location>(new BsonDocumentIndexKeysDefinition<Location>(new BsonDocument
                {
                    { nameof(Location.users) + "." + nameof(LocationUser.visits) + "." + nameof(LocationVisit.visited_at), 1 }
                }))
            });

            StorageClient.Visits.Indexes.CreateMany(new[]
            {
                new CreateIndexModel<Visit>(Builders<Visit>.IndexKeys.Ascending(_ => _.id))
            });
        }
    }
}
