﻿using MongoDB.Bson.Serialization.Attributes;

namespace Travels.Data.Model
{
    internal sealed class Visit
    {
        [BsonId]
        public int id { get; set; }

        public int location { get; set; }

        public int user { get; set; }

        public long visited_at { get; set; }

        public int mark { get; set; }
    }
}
