﻿using System.Collections.Generic;
using MongoDB.Bson.Serialization.Attributes;

namespace Travels.Data.Model
{
    public sealed class Location
    {
        [BsonId]
        public int id { get; set; }

        public string place { get; set; }

        public string country { get; set; }

        public string city { get; set; }

        public int distance { get; set; }

        public List<LocationUser> users { get; set; }
    }

    public sealed class LocationUser
    {
        public int user_id { get; set; }

        public long user_birth_date { get; set; }

        public string user_gender { get; set; }

        public List<LocationVisit> visits { get; set; }
    }

    public sealed class LocationVisit
    {
        public int visit_id { get; set; }

        public long visited_at { get; set; }

        public int mark { get; set; }
    }
}
