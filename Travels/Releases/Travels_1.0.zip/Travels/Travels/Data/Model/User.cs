﻿using System.Collections.Generic;
using MongoDB.Bson.Serialization.Attributes;

namespace Travels.Data.Model
{
    public sealed class User
    {
        [BsonId]
        public int id { get; set; }

        public string email { get; set; }

        public string first_name { get; set; }

        public string last_name { get; set; }

        public string gender { get; set; }

        public long birth_date { get; set; }

        public List<UserLocation> locations { get; set; }
    }

    public sealed class UserLocation
    {
        public int location_id { get; set; }

        public string location_country { get; set; }

        public string location_place { get; set; }

        public int location_distance { get; set; }

        public List<UserVisit> visits { get; set; }
    }

    public sealed class UserVisit
    {
        public int visit_id { get; set; }

        public long visited_at { get; set; }

        public int mark { get; set; }
    }
}
